import { API_URL } from '../constants/constants'
var { extendMoment } = require('moment-range');
var Moment = require('moment');
const moment = extendMoment(Moment);

export const getData = () => (
    new Promise(function (resolve, reject) {
        fetch(API_URL + '/items')
            .then((response) => response.json())
            .then((res) => {
                const trades = res.trades
                setTimeout(() => resolve(trades), 500)
            })
            .catch((error) => {
                reject(error);
            });
    })
)

export const getFilteredData = (searchObj) => (
    new Promise(function (resolve, reject) {
        fetch(API_URL + '/items')
            .then((response) => response.json())
            .then((res) => {
                
                const startDate = moment(searchObj.startDate);
                const endDate = moment(searchObj.endDate);
                const range = moment().range(startDate, endDate);
                const trades = res.trades;
                const filteredTrades = trades.filter((trade) => {
                    let date = moment(trade.tradeDate);
                    console.log(range.contains(date));
                    if (( range.contains(date) && ((searchObj.buy && trade.side === "buy") || (searchObj.sell && trade.side === "sell"))) && (searchObj.commodity === trade.commodity) && (searchObj.counterparty === "" || searchObj.counterparty === trade.counterparty) && (searchObj.location === "" || seaarchObj.location === trade.location)) {
                        return trade;
                    }
                })
                setTimeout(() => resolve(filteredTrades), 500)
            })
            .catch((error) => {
                reject(error);
            });
    })
)

export const updateData = (id, updatedObject) => (
    new Promise(function (resolve, reject) {
        fetch(API_URL + '/items/' + id, {
            method: 'put',
            body: JSON.stringify(updatedObject),
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
        })
            .then((response) => response)
            .then((response) => setTimeout(() => resolve(response.json()), 500))
            .catch((error) => {
                reject(error);
            })
    })
)
