import { call, put, takeEvery, all, take, select } from 'redux-saga/effects'
import * as actionTypes from '../constants/constants.js'
import { getData, getFilteredData, updateData } from '../apis/api'
import * as actions from '../actions/actions'
import { getCoulmnDefs } from '../utils/utils';
import 'regenerator-runtime/runtime'

export function* fetchData() {
  try {
    const data = yield call(getData)
    console.log(data);
    console.log(getCoulmnDefs);
    yield put(actions.getDataSuccess(data));
    let colDefs = getCoulmnDefs(data[0]);
    yield put(actions.setColumnDefs(colDefs));
  } catch (error) {
    yield put(actions.getDataFailure(error.message))
  }

}

export function* fetchFilteredData(action) {
  try {
    const data = yield call(getFilteredData, action.searchObj)
    yield put(actions.getFilteredDataSuccess(data))
    yield put(actions.getDataSuccess(data))
  } catch (error) {
    yield put(actions.getFilteredDataFailure(error.message))
  }
}

export function* updateFilteredData(action){
  try {
    const res = yield call(updateData, action.id, action.updatedObj)
    if(res){
       yield put(actions.updateDataSuccess(res.data))
    }
  } catch (error) {
    yield put(actions.updatDataFailure(error.message))
  }
}

//backgroundTask
export function* watchAndLog() {
  while (true) {
    yield take('*')
    yield select()
  }
}

export function* watchFetchAsync() {
  yield takeEvery(actionTypes.GET_FILTERDDATA_REQUEST, fetchFilteredData)
  yield takeEvery(actionTypes.GET_DATA_REQUEST, fetchData)
  yield takeEvery(actionTypes.UPDATE_DATA_REQUEST, updateFilteredData)
}

export function* rootSaga() {
  yield all([watchFetchAsync()])
}
