import { counterparties, locations, commodities, sides } from '../../constants/constants';
import React from "react";
import Button from '@material-ui/core/Button';

export const TradeForm = (props) => {
    let { trade, changeTrade, createTrade, onToogleCreate } = props
    return (
        <div>

            <div className="trade-form-header">
                Trade Form
                </div>
            <div className="col-md-12 trade-form-col">
                <label className="col-md-3">Trade Id:</label>
                <div className="col-md-2" data-id="tradeId">{trade.tradeId}</div>
            </div>
            <div className="col-md-12 trade-form-col">
                <label className="col-md-3">Trade Date:</label>
                <div className="col-md-2" data-id="tradeDate">{trade.tradeDate}</div>
            </div>

            <div className="col-md-12 trade-form-col">
                <label className="col-md-3">Qty(MT):</label>
                <input type="number" className="col-md-2 form-control" value={trade.qty} data-id="qty" onChange={changeTrade} />
            </div>
            <div className="col-md-12 trade-form-col">
                <label className="col-md-3">Price:</label>
                <div className="col-md-2" data-id="price">{trade.qty * 500}</div>
            </div>
            <div className="form-group col-md-12 trade-form-col">
                <label htmlFor="location" className="col-md-3">Location</label>
                <select onChange={props.changeTrade} data-id="side" className="form-control">
                    {sides.map(option => (
                        <option key={option.value} data-id="side" value={option.value}>
                            {option.label}
                        </option>

                    ))}
                </select>

            </div>
            <div className="form-group col-md-12 trade-form-col">
                <label htmlFor="location" className="col-md-3">Location</label>
                <select onChange={props.changeTrade} data-id="location" className="form-control">
                    {locations.map(option => (
                        <option key={option.value} data-id="location" value={option.value}>
                            {option.label}
                        </option>

                    ))}
                </select>

            </div>
            <div className="form-group col-md-12 trade-form-col">
                <label htmlFor="location" className="col-md-3">Counterparty</label>
                <select onChange={props.changeTrade} data-id="counterparty" className="form-control">
                    {counterparties.map(option => (
                        <option key={option.value} data-id="counterparty" value={option.value}>
                            {option.label}
                        </option>

                    ))}
                </select>

            </div>
            <div className="form-group col-md-12 trade-form-col">
                <label htmlFor="location" className="col-md-3">Commodity</label>
                <select onChange={props.changeTrade} data-id="commodity" className="form-control">
                    {commodities.map(option => (
                        <option key={option.value} data-id="commodity" value={option.value}>
                            {option.label}
                        </option>

                    ))}
                </select>

            </div>

            <div className="col-md-12">
                <Button variant="contained" className="btn btn-md update-trade col-md-3" onClick={createTrade} >
                    Create
                </Button>
                <Button variant="contained" className="btn btn-md update-trade col-md-3" onClick={onToogleCreate} >
                    Cancel
                </Button>
            </div>
        </div>
    );
};


