import React from 'react'
import PropTypes from 'prop-types'
import { DATA_FOUND, TRY_AGAIN } from '../../constants/constants'
const ErrorComponent = (props) => {
    if(props.noDataFound){
        return  (
            <div className='alert alert-info col-md-8 col-xs-offset-1' >
                <strong>{ DATA_FOUND }</strong>
            </div>
        )
    }
    if(props.dataNotFetched && props.errorMessage)
        return (
            <div className='alert alert-danger col-md-10'>
                <strong>{ props.errorMessage }! {TRY_AGAIN}</strong>
            </div>
        )
    return null
}
ErrorComponent.propTypes = {
    dataNotFetched: PropTypes.bool,
    noDataFound: PropTypes.bool,
    errorMessage: PropTypes.string,
};
export default ErrorComponent
