import React from 'react'
import { Link } from 'react-router-dom'
import classNames from 'classnames'

const NavBar = () => {

    const homeClass =  classNames({
      'active': location.pathname === '/',
    })
   
    return (
        <section className='topbar'>
            <ul  className='topnav nav-left'>
                <li>
                    <Link className={homeClass} to='/'>Trades</Link>
                </li>
                <li>
                    <Link  to='/'>Transferes</Link>
                </li>
                  <li>
                    <Link  to='/'>Transports</Link>
                </li>
            </ul>
        </section>
    )
}

export default NavBar
