import React from 'react'
import ErrorComponent from '../common/showerror'
import { LOADER_OPTIONS } from '../../constants/constants'
import Loader from 'react-loader'
import PropTypes from 'prop-types'
import _ from 'lodash'
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-material.css';
import Button from '@material-ui/core/Button';
import Delete from '@material-ui/icons/Delete'
import Add from '@material-ui/icons/Add'
import Edit from '@material-ui/icons/Edit'
import Search from '../search/search'
import moment from 'moment'
import { TradeForm } from '../create/createTrade';
import Popup from "reactjs-popup";

export default class Home extends React.PureComponent {

    constructor(props) {
        super(props);
        this.state = {
            currentTrade: {

            },
            newTrade: {
                tradeDate: moment().format('YYYY-MM-DD'),
                qty: 0,
                location: 'LA',
                commodity: 'AL',
                counterparty: 'Expedia',
                side:'buy',
                tradeId: this.getRandomInt(65801, 98601)
            },
            isEditable: false,
            isCreate: false,
            search: {
                startDate: "2015-01-20",
                endDate: "2018-01-20",
                commodity: "AL",
                sell: true,
                buy: true,
                counterparty: "",
                location: ""
            }
        }
        this.onClear = this.onClear.bind(this);
        this.createTrade = this.createTrade.bind(this);
        this.onChangeNewTrade = this.onChangeNewTrade.bind(this);
        this.onToogleCreate = this.onToogleCreate.bind(this);
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.trades.length > 0 && !(Object.keys(this.state.currentTrade).length > 0)) {
            this.setState({
                currentTrade: nextProps.trades[0]
            })
        }
        if(nextProps.trades.length > 0 && !(nextProps.nonfilteredTrades.length > 0)){
            this.props.actions.setIntialTrades(this.props.trades);
        }
    }

    componentDidMount() {
        this.props.actions.getDataRequest();
        this.onClear();
    }
    onButtonClick() {
        const selectedNodes = this.gridApi.getSelectedNodes()
        const selectedData = selectedNodes.map(node => node.data);
        this.setState({
            currentTrade: selectedData[0]
        })
    }
    onChangeTrade(e) {
        let updateTrade = Object.assign({}, this.state.currentTrade);
        let key = e.currentTarget.dataset.id;
        updateTrade[key] = e.currentTarget.value;
        this.setState({
            currentTrade: updateTrade
        })
        console.log(this.state.currentTrade);
    }
    createTrade() {
        let newTrade = Object.assign({}, this.state.newTrade);
        let basePrice = 500;
        newTrade.price = newTrade.qty * basePrice;
        let updatedTrades = [...this.props.trades, newTrade];
        this.props.actions.getDataSuccess(updatedTrades);
        this.onToogleCreate();
    }

    onChangeNewTrade(e) {
        let updateTrade = Object.assign({}, this.state.newTrade);
        let key = e.currentTarget.dataset.id;
        updateTrade[key] = e.currentTarget.value;
        this.setState({
            newTrade: updateTrade
        })
    }
    updateTrades() {
        let trades = this.props.trades;
        let that = this;
        let newtrades = trades.map((trade) => {
            if (trade.tradeId === that.state.currentTrade.tradeId) {
                trade = Object.assign({}, that.state.currentTrade);
            }
            return trade;
        });
        this.props.actions.getDataSuccess(newtrades);
        this.setState({ isEditable: false });
    }

    onDelete(e) {

        const tradeId = e.currentTarget.id;
        let updatedTrade = this.props.trades.filter((trade) => trade.tradeId !== tradeId);
        this.props.actions.getDataSuccess(updatedTrade);
        this.setState({
            currentTrade: updatedTrade[0]
        })
    }

    onEdit(e) {
        this.setState({
            isEditable: true
        });

    }

    onToogleCreate() {
        this.setState({
            isCreate: !this.state.isCreate
        })
    }

    onSearch() {
        let searchObj = this.state.search;
        
        this.props.actions.getFilteredDataRequest(searchObj);
    }

    onClear() {
        let intialSearch = {
            startDate: "2015-01-20",
            endDate: "2018-01-20",
            commodity: "AL",
            sell: true,
            buy: true,
            counterparty: "",
            location: ""
        }
        this.setState({
            search: intialSearch
        });
        this.props.actions.getDataSuccess(this.props.nonfilteredTrades);
    }

    handleChange(e) {
        let value = e.target.value ? e.target.value : e.currentTarget.value;
        let name = e.target.name ? e.target.name : e.currentTarget.name;
        let updatedSearch = Object.assign({}, this.state.search);
        updatedSearch[name] = (name === "buy" || name === "sell") ? JSON.parse(value) : value;
        this.setState({ search: updatedSearch });
    }
    getRandomInt(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    render() {
        const {
            errorMessage,
            isFetching,
            trades,
            columnDefs,
        } = this.props;

        let updatedTrade = Object.assign({}, this.state.currentTrade);
        console.log(updatedTrade == this.state.currentTrade)
        return (
            <Loader loaded={!isFetching} className='spinner' options={LOADER_OPTIONS}>
                <Popup
                    open={this.state.isCreate}
                    closeOnDocumentClick
                    onClose={this.closeModal}
                >
                    <TradeForm trade={this.state.newTrade} onToogleCreate = {this.onToogleCreate} changeTrade={this.onChangeNewTrade} createTrade={this.createTrade.bind(this)} />
                </Popup>

                <div className="col-md-10 panel panel-default search">
                    <Search search={this.state.search} handleChange={this.handleChange.bind(this)} />
                    <div className="col-md-11 search-btn">
                    <Button variant="contained" className="btn btn-md update-trade pull-right" onClick={this.onClear} >
                        CLEAR
                    </Button>
                    <Button variant="contained" className="btn btn-md update-trade pull-right" onClick={this.onSearch.bind(this)} >
                        SEARCH
                    </Button>
                </div>
                </div>
                


                <div className='col-md-12'>
                    {<ErrorComponent className='error' errorMessage={errorMessage} dataNotFetched={!trades.length > 0} noDataFound={!trades.length > 0} />}
                    {trades && trades.length > 0 && (<div>
                        <div
                            className="ag-theme-material col-md-7 trade panel panel-default component-block"
                            style={{ height: '600px' }}
                        >
                            {columnDefs && trades && trades.length > 0 && (<AgGridReact
                                columnDefs={columnDefs}
                                rowData={trades}
                                rowSelection="single"
                                onGridReady={params => this.gridApi = params.api}
                                onRowClicked={this.onButtonClick.bind(this)}
                            >

                            </AgGridReact>)
                            }
                        </div>
                        <div className="col-md-4 panel panel-default component-block">
                            <Trade updateTrades={this.updateTrades.bind(this)} changeTrade={this.onChangeTrade.bind(this)} isEditable={this.state.isEditable} trade={updatedTrade} editTrade={this.onEdit.bind(this)} deleteTrade={this.onDelete.bind(this)} onToogleCreate={this.onToogleCreate.bind(this)} />
                        </div>
                    </div>)
                    }
                </div>

            </Loader>
        )
    }
}


const Trade = (props) => {
    let { trade, isEditable, changeTrade, updateTrades } = props;
    return (
        <div className="row trade" style={{ height: '600px' }}>
            <div className="col-md-12 trade-heading">
                <div className="col-md-3">Trade Id:</div>
                <div className="col-md-1">{trade.tradeId}</div>
                <div className="col-md-4 col-xs-offset-3">
                    <div className="col-md-4 glyphicon"><Delete id={trade.tradeId} onClick={props.deleteTrade} /></div>
                    <div className="col-md-4 glyphicon"><Edit onClick={props.editTrade} /> </div>
                    <div className="col-md-4 glyphicon"><Add onClick={props.onToogleCreate} /> </div>
                </div>
            </div>
            <div className="col-md-12 tradeCol">
                <div className="col-md-4">Trade Date:</div>
                <div className="col-md-2">{trade.tradeDate}</div>
            </div>
            <div className="col-md-12 tradeCol">
                <div className="col-md-3">Side:</div>
                {isEditable ? (<input type="text" className="col-md-2 form-control" value={trade.side} data-id="side" onChange={changeTrade} />) :
                    <div className="col-md-2 col-xs-offset-1">{trade.side}</div>
                }
            </div>
            <div className="col-md-12 tradeCol">
                <div className="col-md-3">Commodity:</div>
                <div className="col-md-2 col-xs-offset-1">{trade.commodity}</div>
            </div>
            <div className="col-md-12 tradeCol">
                <div className="col-md-3">Qty(MT):</div>
                {isEditable ? (<input type="text" className="col-md-2 form-control" value={trade.qty} data-id="qty" onChange={changeTrade} />) :
                    (<div className="col-md-2 col-xs-offset-1">{trade.qty}</div>)
                }
            </div>
            <div className="col-md-12 tradeCol">
                <div className="col-md-3">Price(MT:</div>
                {isEditable ? (<input type="text" className="col-md-2 form-control" value={trade.price} data-id="price" onChange={changeTrade} />) :
                    (<div className="col-md-2 col-xs-offset-1">{trade.price}</div>)
                }
            </div>
            <div className="col-md-12 tradeCol">
                <div className="col-md-3">Location:</div>
                <div className="col-md-2 col-xs-offset-1">{trade.location}</div>
            </div>
            <div className="col-md-12 tradeCol">
                <div className="col-md-3">Counterparty:</div>
                <div className="col-md-2 col-xs-offset-1">{trade.counterparty}</div>
            </div>
            <div className="col-md-12">
                <Button variant="contained" className="btn btn-md update-trade" onClick={updateTrades} >
                    update
            </Button>
            </div>
        </div>
    )

    Home.propTypes = {
        actions: PropTypes.object.isRequired,
        errorMessage: PropTypes.string,
        trades: PropTypes.array.isRequired,
        searchKey: PropTypes.string.isRequired,
        isFetching: PropTypes.bool.isRequired,
    };

}