import React from "react";
import classNames from "classnames";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormGroup from '@material-ui/core/FormGroup';
import Checkbox from '@material-ui/core/Checkbox';
import { counterparties, locations, commodities } from '../../constants/constants';


const Search = (props) => {

    return (
      <div>
        <TextField
          label="start date"
          name="startDate"
          className="col-md-1"
          placeholder="2017/01/20"
          margin="normal"
          value={props.search.startDate}
          onChange={props.handleChange}
        />
        <div className="sub col-md-1"><sub>to</sub></div>
        <TextField
          label="end date"
          name="endDate"
          className="col-md-1"
          onChange={props.handleChange}
          placeholder="2018/01/20"
          margin="normal"
          value={props.search.endDate}
        />
        <TextField
          select
          label="commodity"
          className="col-md-2 field"
          value={props.search.commodity}
          onChange={props.handleChange}
          margin="normal"
          name="commodity"
        >
          {commodities.map(option => (
            <MenuItem key={option.value} name="commodity" value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField>
       <div className="col-md-2 side field">
       <label className="side">Sides</label>
       <FormGroup row>
       
        <FormControlLabel
          control={
            <Checkbox
              checked={props.search.sell}
              onChange={props.handleChange}
              value={!props.search.sell}
              name="sell"
            />
          }
          label="Sell"
        />
        <FormControlLabel
          control={
            <Checkbox
              checked={props.search.buy}
              onChange={props.handleChange}
              value={!props.search.buy}
              color="primary"
              name="buy"
            />
          }
          label="buy"
        />
        </FormGroup>
       </div>
       <TextField
          select
          label="counterparty"
          className="col-md-2 field"
          value={props.search.counterparty}
          onChange={props.handleChange}
          margin="normal"
          name="counterparty"
        >
          {counterparties.map(option => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField>
        <TextField
          select
          label="location"
          className="col-md-2 field"
          value={props.search.location}
          onChange={props.handleChange}
          margin="normal"
          name="location"
        >
          {locations.map(option => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField>
      </div> 
    );
  
};

export default Search;

