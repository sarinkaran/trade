import * as stateActions from '../actions/actions'
import { connect } from 'react-redux'
import Home from '../components/home/home'
import { bindActionCreators } from 'redux'


const mapStateToProps = (state, props) => {
    return {
        trades: state.trades.trades,
        nonfilteredTrades: state.trades.nonfilteredTrades,
        columnDefs: state.trades.columnDefs,
        searchKey: state.search.searchKey,
        isFetching: state.trades.isFetching,
        errorMessage: state.trades.errorMessage,
    }
}


const mapDispatchToProps = (dispatch) => {
    return {
        actions: bindActionCreators(stateActions, dispatch),
    }
}
const HomeContainer = connect(mapStateToProps, mapDispatchToProps)(Home);
export default HomeContainer
