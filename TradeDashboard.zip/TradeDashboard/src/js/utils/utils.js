export const getVisibletrades = (trades, param) => trades.filter((techie) => (techie.name.toLowerCase().includes(param)))
export const getCoulmnDefs = (trade) => {
    const colDefs = [];
    const keys  = Object.keys(trade);
    keys.map((key) => {
       
        const def = {
            'headerName':  key[0].toUpperCase() + key.slice(1),
            'field':key,
             'sortable': true, 
             'filter' : true
        }
        colDefs.push(def);
    })
    return colDefs
}