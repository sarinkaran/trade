import { combineReducers } from 'redux'
import {trades, search} from './reducer'

const techinfomasterReducer = combineReducers({
  trades,
  search,
})

export default techinfomasterReducer;
