# TECHINFOMASTERS

STEPS  TO START

1) NPM INSTALL
2) NPM START
3) Production : npm build:prod

Description:
This app describes details of masters of technologies in fron-end
It contains 3 pages 
HOME: It provides list of masters
Search:here you can search any master
Detials:It provides  profile of se;ected master
