const path = require('path');
const webpack = require("webpack")
const plugins = require('./webpack.config.base').plugins
const env = process.env || 'dev';
const isProd = env === 'prod';
const ExtractTextPlugin = require("extract-text-webpack-plugin");

const autoprefixer = require('autoprefixer');
const config = {
    context: path.resolve('src'),
    entry: {
        bundle: ["./js/app.jsx"],
        vendor: [
            'react',
            'react-dom',
            'react-redux',
            'react-router',
            'redux',
            'redux-saga',
            'lodash',
            'prop-types',
            'react-loader',
            'react-router-dom'
        ]
    },
    output: {
        path: path.resolve('build/'),
        publicPath: '/',
        filename: "[name].[hash].js",
        //chunkFilename: '[name].[chunkhash].js'
    },
    devServer: {
        historyApiFallback: true,
        contentBase: path.join(__dirname, 'src', 'html'),
        hot: true,
        inline: true
    },
    devtool: isProd ? 'source-map' : 'cheap-module-source-map',
    stats: {
        colors: true,
        reasons: true,
        chunks: true
    },
    module: {
        rules: [{
            test: [/\.js$/, /\.jsx$/],
            exclude: /(node_modules)/,
            loader: 'babel-loader',
            query: {
                presets: ['es2015', 'react']
            }
        },
        {
            test: /\.css$/,
            use: [
                require.resolve('style-loader'),
                {
                    loader: require.resolve('css-loader'),
                    options: {
                        importLoaders: 1,
                    },
                },
                {
                    loader: require.resolve('postcss-loader'),
                    options: {
                        // Necessary for external CSS imports to work
                        // https://github.com/facebookincubator/create-react-app/issues/2677
                        ident: 'postcss',
                        plugins: () => [
                            require('postcss-flexbugs-fixes'),
                            autoprefixer({
                                browsers: [
                                    '>1%',
                                    'last 4 versions',
                                    'Firefox ESR',
                                    'not ie < 9', // React doesn't support IE8 anyway
                                ],
                                flexbox: 'no-2009',
                            }),
                        ],
                    },
                },
            ],
        },
        {
    test: /\.less$/,
        exclude: /(node_modules)/,
            use: ExtractTextPlugin.extract({
                fallback: 'style-loader',
                //resolve-url-loader may be chained before less-loader if necessary
                use: ['css-loader', 'less-loader']
            })
},
{
    test: /\.(png|jpg|gif|json)$/,
        use: [
            {
                loader: 'file-loader',
                options: {}
            }
        ]
}
        ]
    },
resolve: {
    extensions: ['.jsx', '.js', '.es6']
},
plugins: plugins,
}
if (isProd) {
    config.entry.unshift('webpack-hot-middleware/client?path=/__webpack_hmr&timeout=20000', 'webpack/hot/only-dev-server');
}
module.exports = config
